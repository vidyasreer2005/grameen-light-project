package com.example.grameenlight

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.google.maps.android.compose.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.firebase.database.FirebaseDatabase

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GrameenLightApp()
                }
            }
        }
    }
}

@Composable
fun GrameenLightApp() {
    val database = FirebaseDatabase.getInstance().getReference("streetlights")

    // Default position (KGF, Kolar)
    val kgf = LatLng(12.9580, 78.2711)
    val cameraPositionState = rememberCameraPositionState {
        position = com.google.android.gms.maps.model.CameraPosition.fromLatLngZoom(kgf, 15f)
    }

    // State for the reporting dialog
    var showDialog by remember { mutableStateOf(false) }
    var selectedPoleId by remember { mutableStateOf("") }

    Scaffold(
        bottomBar = {
            BottomAppBar {
                Text(modifier = Modifier.padding(16.dp), text = "Grameen-Light: Tap a pole to report")
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState
            ) {
                // Example Marker for Pole 064
                Marker(
                    state = MarkerState(position = kgf),
                    title = "Pole_064",
                    snippet = "Tap to report issue",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN),
                    onClick = {
                        selectedPoleId = "Pole_064"
                        showDialog = true
                        true
                    }
                )
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Report Issue for $selectedPoleId") },
            text = { Text("What is the status of this streetlight?") },
            confirmButton = {
                Column {
                    Button(onClick = {
                        database.child(selectedPoleId).child("status").setValue("FUSED")
                        showDialog = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("Fused (Dark)") }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(onClick = {
                        database.child(selectedPoleId).child("status").setValue("ON_DAYTIME")
                        showDialog = false
                    }, modifier = Modifier.fillMaxWidth()) { Text("Wasting Energy (ON in Day)") }
                }
            }
        )
    }
}